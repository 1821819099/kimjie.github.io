# 5iux.github.io


很多朋友喜欢静态版本，今天给大家放出个（原来的php版还维护）   

喜欢的可自行设置主页，或者自己下载源码修改

链接1：[https://sou.5iux.cn/](https://sou.5iux.cn/)    

链接2：[https://cn5iux.gitee.io/](https://cn5iux.gitee.io/)    

链接3：[https://5iux.github.io/](https://5iux.github.io/)   

链接4：[https://5iux.netlify.app/](https://5iux.netlify.app/)   

 

![图](https://cdn.jsdelivr.net/gh/5iux/uploads/pic/20200923154548.gif)   


![图](https://cdn.jsdelivr.net/gh/5iux/uploads/pic/20200724164819.png)   

     

    


## 放个吃饭链接

虽然我也不喜欢广告（狗头）

[![吃饭链接](https://cdn.5iux.cn/pic/20201010171915.jpg "点击查看")](https://wat.dyartstyle.com/)

